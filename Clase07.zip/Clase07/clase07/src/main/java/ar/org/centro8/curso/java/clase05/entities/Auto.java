package ar.org.centro8.curso.java.clase05.entities;

public class Auto {
    private String marca;
    private String modelo;
    private String color;
    
    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    
    /** 
     * @return String
     */
    @Override
    public String toString() {
        return "Auto [color=" + color + ", marca=" + marca + ", modelo=" + modelo + "]";
    }

    
    /** 
     * @return String
     */
    public String getMarca() {
        return marca;
    }

    
    /** 
     * @param marca
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    
    /** 
     * @return String
     */
    public String getModelo() {
        return modelo;
    }

    
    /** 
     * @param modelo
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    
    /** 
     * @return String
     */
    public String getColor() {
        return color;
    }

    
    /** 
     * @param color
     */
    public void setColor(String color) {
        this.color = color;
    }
 
}
