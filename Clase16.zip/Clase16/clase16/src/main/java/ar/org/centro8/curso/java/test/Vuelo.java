package ar.org.centro8.curso.java.test;

public class Vuelo {
    private final String nombre;
    private int cantidadPasajes;
    
    public Vuelo(String nombre, int cantidadPasajes) {
        this.nombre = nombre;
        this.cantidadPasajes = cantidadPasajes;
    }

    public synchronized void venderPasajes(int cantidadPasajesPedidos) 
            throws NoHayMasPasajesException {
        if(cantidadPasajes<cantidadPasajesPedidos) 
            throw new NoHayMasPasajesException(nombre, cantidadPasajes, cantidadPasajesPedidos);
        this.cantidadPasajes-=cantidadPasajesPedidos;      
    }

    @Override
    public String toString() {
        return "Vuelo [cantidadPasajes=" + cantidadPasajes + ", nombre=" + nombre + "]";
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidadPasajes() {
        return cantidadPasajes;
    }
    
}
