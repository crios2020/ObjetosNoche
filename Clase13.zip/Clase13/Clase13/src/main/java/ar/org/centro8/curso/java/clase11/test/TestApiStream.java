package ar.org.centro8.curso.java.clase11.test;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.clase11.entities.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        // API STREAM

        List<Persona>list=new ArrayList();

        list.add(new Persona("Juan","Morales",23));
        list.add(new Persona("Victor","Morales",23));
        list.add(new Persona("Ana","Morales",23));
        list.add(new Persona("Beatriz","Morales",23));
        list.add(new Persona("Carlos","Morales",23));
        list.add(new Persona("Carlos","Morales",9));
        list.add(new Persona("Juan", "Morales", 23));
        list.add(new Persona("Gabriel", "Bando", 45));        
        list.add(new Persona("Fernando", "Tigo", 39)); 
        list.add(new Persona("Javier","Costa",34));
        list.add(new Persona("Lorena","Gomez",38));
        list.add(new Persona("Horacio","Mendez",29));
        list.add(new Persona("Eliana","Correa",39));
        list.add(new Persona("Laura","Correa",39));
        list.add(new Persona("Laura","Sosa",33));
        list.add(new Persona("Laura","Perez",32));
        list.add(new Persona("Lautaro","Correa",39));
        list.add(new Persona("Laureano","Correa",39));
        list.add(new Persona("laura","Mendez",39));
        list.add(new Persona("LAURA","Torres",42));
        list.add(new Persona("Mirta","Torres",42));
        list.add(new Persona("Marta","Torres",42));
        list.add(new Persona("Marcela","Torres",42));
        list.add(new Persona("Marcelo","Torres",42));
        list.add(new Persona("Omar","Torres",42));
        list.add(new Persona("Armando","Torres",42));


        // select * from personas;
        System.out.println("**********************************************");
        //list.forEach(System.out::println);
        list.stream().forEach(System.out::println);


        // select * from personas nombre='Laura';
        System.out.println("**********************************************");
        // list
        //        .stream()
        //        .filter(p->p.getNombre().equals("laura"))
        //        .forEach(System.out::println);

        list
               .stream()
               .filter(p->p.getNombre().equalsIgnoreCase("laura"))
               .forEach(System.out::println);

        // for(Persona p:list){
        //     if(p.getNombre().equals("Laura")){
        //         System.out.println(p);
        //     }
        // }

        // select * from personas nombre like 'lau%';
        System.out.println("**********************************************");
        list
                .stream()
                .filter(p->p.getNombre().toLowerCase().startsWith("lau"))
                .forEach(System.out::println);
        
        // select * from personas nombre like '%a';
        System.out.println("**********************************************");        
        list
                .stream()
                .filter(p->p.getNombre().toLowerCase().endsWith("a"))
                .forEach(System.out::println);
                
        // select * from personas nombre like '%ar%';
        System.out.println("**********************************************");        
        list
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains("ar"))
                .forEach(System.out::println);

        // select * from personas nombre like '____';
        System.out.println("**********************************************");
        list
                .stream()
                .filter(p->p.getNombre().length()==4)
                .forEach(System.out::println);

        // select * from personas nombre like '____%';
        System.out.println("**********************************************");
        list
                .stream()
                .filter(p->p.getNombre().length()>=4)
                .forEach(System.out::println);
        
        // select count(*) from personas nombre = 'laura';
        System.out.println("**********************************************");
        System.out.println(
            list
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("laura"))
                .count()
        );

        // select count(*) from personas nombre = 'laura' and edad>=30;
        System.out.println("**********************************************");
        // System.out.println(
        //     list
        //         .stream()
        //         .filter(p->p.getNombre().equalsIgnoreCase("laura")
        //                     && p.getEdad()>=30)
        //         .count()
        // );

        System.out.println(
            list
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("laura"))
                .filter(p->p.getEdad()>=30)
                .count()
        );

            //pendientes
            // name=xx or apellido=xx
            //order by
            //min max
            //subqueries


    }
}
