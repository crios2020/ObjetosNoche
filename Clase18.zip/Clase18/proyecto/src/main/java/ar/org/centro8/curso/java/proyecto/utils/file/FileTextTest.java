package ar.org.centro8.curso.java.proyecto.utils.file;


public class FileTextTest{
    public static void main(String[] args) {
        
        // String texto="";

        // StringBuilder sb=new StringBuilder();

        // for(int a=0;a<=300000;a++){
        //     texto+="x";
        //     //sb.append("x");
        // }

        String file="texto.txt";
        I_File fText=new FileText(file);
        System.out.println(fText.getText());

    }
}