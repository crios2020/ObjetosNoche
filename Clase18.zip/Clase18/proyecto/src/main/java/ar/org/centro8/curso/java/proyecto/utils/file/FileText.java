package ar.org.centro8.curso.java.proyecto.utils.file;

import java.io.File;
import java.io.FileReader;
import java.util.List;

public class FileText implements I_File{

    private File file;
 
    public FileText(File file) {
        this.file = file;
    }

    public FileText(String file) {
        this.file = new File(file);
    }

    @Override
    public String getText() {
        StringBuilder sb=new StringBuilder();
        int car;
        String text = "";
        try (FileReader in = new FileReader(file)){
            while((car=in.read())!=-1){
                //text+=(char)car;
                sb.append((char)car);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        //return text;
        return sb.toString();
    }

    @Override
    public void setText(String text) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void appendText(String text) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public List<String> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

}