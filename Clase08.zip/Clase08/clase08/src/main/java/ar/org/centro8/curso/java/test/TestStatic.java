package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Auto;

public class TestStatic {
    public static void main(String[] args) {
        
        /*
            Modificador static.
            Los miembros estaticos (atributos o métodos) pertenecen a la clase
                y no a los objetos de la misma.
            Los miembros estaticos pueden ser llamados sin crear un objeto de
                la clase.
            Los atributos estaticos que sean llamados desde un método. requiere
            que el método sea estatic.

            Cuidado.... no abusar del static por que no es programación orientada
                    a objetos!!!!!!!
        */
        
        System.out.println("Hola");

        Auto.acelerar(10);

        System.out.println("-- auto1 --");
        Auto auto1 = new Auto("Fiat","Idea","Verde");
        Auto.acelerar(20);
        System.out.println(auto1+" "+Auto.getVelocidad());

        System.out.println("-- auto2 --");
        Auto auto2 = new Auto("WV","Gol","Blanco");
        Auto.acelerar(20);
        System.out.println(auto2+" "+Auto.getVelocidad());


    }
}
