package ar.org.centro8.curso.java.interfaces;

public interface I_File {
    
    /*
        Interfaces:
            - Una Interface no contiene atributos ni métodos constructores.
            - Puede contener constantes o atributos de clase (static).
            - Todos los miembros de una interface son publicos.
            - Los métodos de una interface son abstractos.
            - Una clase puede implementar muchas interfaces.
    */

    /**
     * La java Doc se hereda
     * Este método escribe dentro del archivo.
     * @param text texto a escribir
     */
    void setText(String text);

    /**
     * Este método devuelve el contenido del archivo.
     * @return retorna el texto con el contenido de un archivo.
     */
    String getText();

    /*
        Interfaces en Java 8 o superior.
        Métodos default: en java 8 o superior existen los métodos default.
        Estos métodos tienen cuerpo (código) y es heredado a las 
        implementaciones
    */

    default void info(){
        System.out.println("Interface I_File");
    }


}
