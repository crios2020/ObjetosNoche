
/**
 * Clase principal del proyecto.
 */
public class Clase02{
    /**
     * Punto de entrada del proyecto
     * @param args argumentos que ingresan por consola.
     */
    public static void main(String[] args) {
        System.out.println("Clase 02");
        System.out.println(System.getProperty("java.version"));

        //Tema pendiente String[] args
        System.out.println("Longitud args:  "+args.length);
        for(int a=0; a<args.length; a++){
            System.out.println(args[a]);
        }

        //Uso de varargs JDK 5 o sup.
        String[] vector={"Primavera", "Verano", "Otoño", "Invierno"};
        metodo1(vector);
        //metodo1("Primavera", "Verano", "Otoño", "Invierno"); //Error no recibe varargs como parametro

        metodo2(vector);
        metodo2("Primavera", "Verano", "Otoño", "Invierno");

        // Linea de comentarios
        /* Bloque de comentarios /*
        /**
            Comentario JavaDOC
            Este comentario puede verse desde fuera del archivo binario.
            Debe colocarse este comentario delante de una declaración de clase
            o declaración de método.
        */

        //Como crear una javaDoc html
        //javadoc -d docs/ -version -author -use *.java

        // Tipo de datos primitivos

        // Lenguajes de tipado fuerte   Java, C++, C#, Visual Basic
        // Lenguajes de tipado debil    JavaScript, Python, PHP

        // Tipo de datos enteros
        
        // Tipo de datos boolean            1 byte
        boolean bo=true;            // 1
        System.out.println(bo);

        bo=false;                   // 0
        System.out.println(bo);
        
        // Tipo de datos byte               1 byte      -128 127
        byte by=100;
        System.out.println(by);

        // Tipo de datos short              2 bytes      
        short sh=1000;
        System.out.println(sh);

        // Tipo de datos int                4 bytes
        int in=2000000000;
        System.out.println(in);

        // Tipo de datos long               8 bytes
        long lo=3000000000L;
        System.out.println(lo);

        // Tipo de datos char               2 bytes UNICODE
        char ch=120;
        System.out.println(ch);
        ch='a';
        System.out.println(ch);
        ch-=32;
        System.out.println(ch);

        //Tipo de datos de punto flotante
        // Tipo de datos float 32 bits
        float fl=4.38f;
        System.out.println(fl);

        // Tipo de datos double 64 bits
        double dl=4.38;
        System.out.println(dl);

        fl=10;
        dl=10;

        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=100;
        dl=100;

        System.out.println(fl/3);
        System.out.println(dl/3);

        // Clase BigDecimal

        //Clase String
        String st="Esto es una cadena de texto!";
        System.out.println(st);

        String t="hola";
        System.out.println(t);
        /*
            hasta JDK 9       private final char[] value;   // 8 bytes
            JDK 10 o sup.     private final byte[] value;   // 4 bytes
        */

        //Tipo de datos var     JDK 9 o sup.
        var var1=2000;          //int
        var1=20;
        // var1=3.26; //error variable int

        var var2=true;          //boolean
        var var3=3.23;          //double
        var var4=3.23d;         //double
        var var5=3.23f;         //float
        var var6='a';           //char
        var var7="a";           //String
        var var8=2L;            //long

        Object object=var4;
        System.out.println(object.getClass().getSimpleName());

        // Recorrer el string st
        System.out.println(st);
        for(int a=0;a<st.length();a++){
            System.out.print(st.charAt(a));
        }
        System.out.println();

        //Temas pendiente
        //Imprimir en minusculas.
        //Imprimir en mayusculas.
        //Operador Ternario.


    }

    /**
     * Método que ingresa un array como argumento.
     * @param argumentos
     */
    public static void metodo1(String[] argumentos){
        for(int a=0;a<argumentos.length; a++){
            System.out.println(argumentos[a]);
        }
    }

    /**
     * Método que ingresa un varargs como argumento
     * @param argumentos
     */
    public static void metodo2(String... argumentos){
        for(int a=0;a<argumentos.length; a++){
            System.out.println(argumentos[a]);
        }
    }



}