package ar.org.centro8.curso.java.proyecto.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
