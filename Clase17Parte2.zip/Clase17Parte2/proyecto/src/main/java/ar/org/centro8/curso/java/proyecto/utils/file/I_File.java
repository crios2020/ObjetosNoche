package ar.org.centro8.curso.java.proyecto.utils.file;

public interface I_File{
    default void print(){ System.out.println(getText()); }
    String getText();
    void setText(String text);
    void append(String text);
    default void addLine(String line){ append(line+"\n"); }
    default void clear(){ setText(""); }
}