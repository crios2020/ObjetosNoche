package ar.org.centro8.curso.java.clase11.test;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import ar.org.centro8.curso.java.clase11.entities.Persona;

public class TestCollection {
    public static void main(String[] args) {
        
        
        //Collecciones
        Persona[] personas=new Persona[4];
        personas[0]=new Persona("Javier","Costa",34);
        personas[1]=new Persona("Lorena","Gomez",38);
        personas[2]=new Persona("Horacio","Mendez",29);
        personas[3]=new Persona("Eliana","Correa",39);

        //Recorrido por indices
        //for(int a=0;a<personas.length;a++){
        //    System.out.println(personas[a]);
        //}

        //Recorrido forEach JDK 5
        //for(Persona persona : personas) System.out.println(persona);

        Arrays.asList(personas).forEach(System.out::println);

        //Interface List
        //Representa una lista dinamica tipo vector con indices

        List list;
        list=new ArrayList();       //Lista Dinamica
        //list=new LinkedList();
        //list=new Vector();

        list.add(new Persona("Gabriel", "Bando", 45));          // 0
        list.add(new Persona("Fernando", "Tigo", 39));          // 2
        list.add("Hola");                                       // 3
        list.add(22);                                           // 4
        list.add("Chau");                                       // 5
        list.add(1, "Miércoles");                               // 1
        //list.remove(5);

        System.out.println("****************************************");
        //Recorrido con indices
        //for(int a=0;a<list.size();a++) System.out.println(list.get(a));

        //Recorrido forEach
        //for(Object o:list) System.out.println(o);
 
        //método forEach() JDK 8 o superior
        //Lambda Expression jdk 8 sup 
        //list.forEach(o->System.out.println(o));
        //list.forEach(o->{
        //    System.out.println(o);
        //});

        list.forEach(System.out::println);


        //Pendientes
        // Uso de Generics
        // Set
        // Interface Comparable
        // Pilas Colas
        // Maps
        // API Stream

        

    }
}
