public class Hola{
	/*
	 * La clase publica debe tener el mismo nombre que el archivo.
	 * Solo puede existir un miembro publico por archivo.
	 * Un archivo puede contener Clases, Interfaces o enums.
	 */ 
	 
	 public static void main(String[] args){
		 //Tema pendiente Explicar String[] args.
		 
		 System.out.println("Hola Mundo!!");
	 }
}
class Lunes{}
class Martes{}
interface Ejecutable{}
enum Semana{}
