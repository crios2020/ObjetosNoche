package ar.org.centro8.curso.java.test;

public class NoHayMasPasajesException extends Exception{
    private final String nombreVuelo;
    private final int cantidadPasajesDisponibles;
    private final int cantidadPasajesPedidos;

    public NoHayMasPasajesException(String nombreVuelo, int cantidadPasajesDisponibles, int cantidadPasajesPedidos) {
        this.nombreVuelo = nombreVuelo;
        this.cantidadPasajesDisponibles = cantidadPasajesDisponibles;
        this.cantidadPasajesPedidos = cantidadPasajesPedidos;
    }

    @Override
    public String toString() {
        return "El vuelo "+nombreVuelo+" no tiene "+cantidadPasajesPedidos
                +" pasajes, solo tiene "+cantidadPasajesDisponibles+" pasajes.";
    }

    @Override
    public String getMessage() {
        return this.toString();
    }

    public String getNombreVuelo() {
        return nombreVuelo;
    }

    public int getCantidadPasajesDisponibles() {
        return cantidadPasajesDisponibles;
    }


    public int getCantidadPasajesPedidos() {
        return cantidadPasajesPedidos;
    }
      
}
