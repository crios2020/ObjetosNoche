public class Clase03 {
    public static void main(String[] args) {

        // Como crear una javaDoc html
        // javadoc -d docs/ -version -author -use *.java

        // no funciona por que falta configurar variables de entorno JAVA_HOME y
        // JRE_HOME
        // https://www.tecnicomo.com/windows/como-configurar-las-variables-de-entorno-java_home-y-jre_home-en-windows-10/

        String st = "Esto es una cadena de texto!";
        System.out.println(st);
        for (int a = 0; a < st.length(); a++) {
            System.out.print(st.charAt(a));
        }
        System.out.println();

        // Temas pendiente
        // Imprimir en minusculas.
        for (int a = 0; a < st.length(); a++) {
            char car = st.charAt(a);
            if (car >= 65 && car <= 90) car += 32;
            System.out.print(car);
        }
        System.out.println();

        // Operador Ternario ?
        for (int a = 0; a < st.length(); a++) {
            char car = st.charAt(a);
            System.out.print((car >= 65 && car <= 90) ? car += 32 : car);
        }
        System.out.println();

        // Imprimir en mayusculas.
        for (int a = 0; a < st.length(); a++) {
            char car = st.charAt(a);
            System.out.print((car >= 97 && car <=122)?car-=32:car);
        }
        System.out.println();

        System.out.println(st.toLowerCase());
        System.out.println(st.toUpperCase());


        

    }
}