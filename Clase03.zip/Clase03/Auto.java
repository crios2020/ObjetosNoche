//declaración de clases
public class Auto {
    
    //Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //Constructores pendientes

    //Métodos
    void acelerar() {                                           //acelerar
        velocidad+=10;    
        if(velocidad>100)   velocidad=100;
    }

    //Método sobrecargado
    void acelerar(int kilometros){                              //acelerarInt
        // int kilometros es un párametro de entrada
        velocidad+=kilometros;
        if(velocidad>100)   velocidad=100;
    }

    //void acelerar(int r){ }                                   //acelerarInt

    void acelerar(int r, boolean x){ }                          //acelerarIntBoolean

    void acelerar(int r, int x) { }                             //acelerarIntInt

    void frenar()   { 
        velocidad-=10;    
        if(velocidad<0)     velocidad=0;
    }

}//end class
