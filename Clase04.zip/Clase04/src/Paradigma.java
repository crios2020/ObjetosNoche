package src;
import javax.swing.JOptionPane;

public class Paradigma {
    public static void main(String[] args) {
        /*
            Paradigma de Objetos

            Clase:  Son plantillas para construir objetos.
                    Representan ideas genericas del mundo real.
                    Se detectan como sustantivos.
                    y se escriben en singular iniciando con mayusculas.
                    Ejemplo de Clases:  Auto, Alumno, Computadora
            
            
            Clases en java: Todas las clases en java son objetos de la clase 
                    java.lang.Class.
            
            Atributos:  Los atributos(adjetivo) describen a la clase 
                    y tiene un tipo de datos asignado.
                    Los atributos son variables contenidas dentro de la clase.
                    La clase define los atributos y los objetos completan el estado.
            
            Atributos en Java: son objetos de la clases java.lang.reflect.Field.


            Objetos:    Son instancias de la clase, representan una situación en particular
                        El estado es el valor de sus atributos, cada objeto tiene un estado 
                        propio.

            Objetos en Java: en Java cualquier objeto puede ser contenido en un 
                        objeto de la clase java.lang.Object.

            Métodos:    Son acciones que realiza la clase, se encuentran como verbos.
                        Los analistas funcionales las llaman operaciones.
                        pueden tener parametros de entrada y un parametro de salida.
                    
            Métodos en Java: son objetos de la clase java.lang.reflect.Method

            Párametros de entrada:  Son valores que ingresan a un método, para ser
                        usados dentro del método. Un párametro es una variable que 
                        solo vive dentro del método. Tiene un tipo de datos asociado.
            
            Sobrecarga de métodos:  Es la presencia de métodos con el mismo nombre dentro
                        de una clase. Pero debe variar la firma de párametros de entrada.
        
            Métodos con devolución de valor:    Los métodos pueden devolver un valor una
                        vez terminada la operación, ese valor tiene un tipo de datos asociado.
                        Si no devuelve valor, se coloca void


            Constructores:  Los constructores son métodos que inicializan los objetos.
                            Tienen el mismo nombre que la clase y pueden recibir parametros
                            de entrada, se pueden sobrecargar y no tienen devolución de valor.
                            Se invoca automaticamente con la palabra new al crear un objeto.
                            Cuando una clase no tiene constructor Java agrega un constructor
                            vacio al compilar.

            Constructores en Java:  en Java los constructores son objetos de la clase
                            java.lang.reflect.Constructor.

        */

        //Class clazz=null;

        // -- auto1 --
        System.out.println("--auto1--");
        Auto auto1=new Auto();

        //Colocar estado al objeto auto1
        auto1.marca="Fiat";
        auto1.modelo="Mobi";
        auto1.color="Rojo";
        auto1.acelerar();           // 10
        auto1.acelerar();           // 20
        auto1.acelerar();           // 30
        auto1.frenar();             // 20
        auto1.acelerar(23);         // 43

        //se imprime el estado.
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
        
        
        //Los atributos númericos se inicializan automaticamente en 0.
        //Los atributos String se inicializan automaticamente en null.

        int x;
        //System.out.println(x);  //Error variable no inicializada
        //Los primitivos no son nuleables
        //x=null;
    
        // -- auto2 --
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Ford";
        auto2.modelo="Fiesta";
        auto2.color="Negro";

        for(int a=0; a<=60; a++) auto2.acelerar();

        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);

        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Renault", "Kango", "Bordo");
        auto3.acelerar(45);
        auto3.imprimirVelocidad();
        System.out.println(auto3.obtenerVelocidad());

        JOptionPane.showMessageDialog(null, "Velocidad: "+auto3.obtenerVelocidad());

        //Método toString()
        System.out.println(auto3.getEstado());
        System.out.println(auto3.toString());
        System.out.println(auto3);

        /*
                Modificadores de visibilidad (Para miembros de clases Atributos o Métodos)

                Modificador             Alcance
                default                 El miembro es visible desde la misma clase y clases
                                        del mismo paquete.
        
                public                  El miembro es visible desde cualquier clase.

                private                 El miembro es visible desde la misma clase.

                protected               El miembro es visible desde la misma clase, desde 
                                        clases hijas y desde clases del mismo paquete.

        */

        Auto autoX=new Auto("Citroen","C4","Bordo");
        autoX.acelerar(350);
        autoX.velocidad=50000;
        System.out.println(autoX);

        Empleado empleado1=new Empleado(1, "Juan", "Zamora", 25000);
        //empleado1.sueldoBasico=300000;
        empleado1.setSueldoBasico(300000);
        System.out.println(empleado1);

    }
}
