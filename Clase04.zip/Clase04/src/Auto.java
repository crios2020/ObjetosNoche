package src;
//declaración de clases
public class Auto {
    
    //Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //Constructores pendientes

    /**
     * Este método fue deprecado por Carlos Ríos el 21/03/2022.
     * Por resultar inseguro.
     * Usar en su reemplazo Auto(String marca, String modelo, String color)
     */
    @Deprecated             //Annotation JDK 5 o sup
    Auto(){} //Constructor vacio

    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }

    //Métodos
    void acelerar() {                                           //acelerar
        acelerar(10);       //llamado de método dentro de la misma clase
    }

    //Método sobrecargado
    void acelerar(int kilometros){                              //acelerarInt
        // int kilometros es un párametro de entrada
        velocidad+=kilometros;
        if(velocidad>100)   velocidad=100;
    }

    //void acelerar(int r){ }                                   //acelerarInt

    @Deprecated 
    void acelerar(int r, boolean x){ }                          //acelerarIntBoolean

    @Deprecated 
    void acelerar(int r, int x) { }                             //acelerarIntInt

    void frenar()   { 
        velocidad-=10;    
        if(velocidad<0)     velocidad=0;
    }

    //método sin devolución de parametros
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    //método con devolución de parametros
    int obtenerVelocidad(){
        return velocidad;
    }

    String getEstado(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }

    @Override
    public String toString(){
        //Método heredado de la clase Object
        return marca+", "+modelo+", "+color+", "+velocidad;
    }

}//end class
