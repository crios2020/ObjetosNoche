package src.org.centro8.curso.java.clase04;
import src.Auto;
public class Test{
    public static void main(String[] args) {
        //Auto autox=new Auto();
    }
}