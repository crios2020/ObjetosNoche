package ar.org.centro8.curso.java.test;

import java.io.FileReader;

public class TestException {
    public static void main(String[] args) {
        
        //System.out.println(10/0);
        //System.out.println("Esta linea no se ejecuta!");

        /*
            Estructura Try Catch Finally

            try{                        OBLIGATORIO

                //Ubicar en este bloque, todas las sentencias que pueden arrojar una Exception.
                //Estas sentencias tienen un costo mayor de hardware.
                //Si pueden ejecutarse bien se ejecutan
                //sino lanzan una exception, esa exception no detiene el programa.

            } catch(Exception e){       OBLIGATORIO

                //Este bloque se ejecuta en caso de ocurrir una exception en try
                //Se recibe como parametro un objeto del tipo Exception

            } finally {                 OPCIONAL

                //Este bloque se ejecuta siempre, ocurra una exception o no
                //Las variables declaradas en Try o Catch estan fuera de scope (Alcance)
            }
            //El programa termina normalmente
        */
            /*
            try {
                System.out.println(10/1);
                System.out.println("Esta linea no se ejecuta!");
            } catch (Exception e) {
                System.out.println("Ocurrio un error!");
                System.out.println(e);
            } finally {
                System.out.println("El programa termina termina normalmente!");
            }

            try {
                System.out.println(10/1);
                System.out.println("Esta linea no se ejecuta!");
            } catch (Exception e) {
                System.out.println("Ocurrio un error!");
                System.out.println(e);
            }
            System.out.println("El programa termina termina normalmente!");
            */

                //GeneradorExceptions.generar();
                //GeneradorExceptions.generar(true);
                //GeneradorExceptions.generar("26v");
                //GeneradorExceptions.generar(null,3);
                //GeneradorExceptions.generar("hola",-2);
                //FileReader in=new FileReader("texto.txt");

            try {
                //GeneradorExceptions.generar();
                //GeneradorExceptions.generar(true);
                //GeneradorExceptions.generar("26v");
                //GeneradorExceptions.generar(null,3);
                //GeneradorExceptions.generar("hola",-2);
                //FileReader in=new FileReader("texto.txt");
                System.out.println("*****************************");
            } catch (Exception e) {
                e.printStackTrace();
            }


            //Captura personalizada de Exceptions
            try {
                //Tema pendiente

                //Repasar

                // Pendiente || herencia Exception

                //GeneradorExceptions.generar();
                //GeneradorExceptions.generar(true);
                //GeneradorExceptions.generar("29x");
                //GeneradorExceptions.generar(null,2);
                //GeneradorExceptions.generar("hola",20);
                FileReader in=new FileReader("texto.txt");
            } catch (ArithmeticException e)             { System.out.println("División / 0");
            } catch (ArrayIndexOutOfBoundsException e)  { System.out.println("Indice Fuera de Rango");
            } catch (NumberFormatException e)           { System.out.println("Formato de número incorrecto!");
            } catch (NullPointerException e)            { System.out.println("Puntero Nulo");
            } catch (StringIndexOutOfBoundsException e) { System.out.println("Indice Fuera de Rango");
            } catch (Exception e)                       { System.out.println("Error no esperado!"); }


            //Pendiente Uso de Validaciones para reglas de negocio
            
    }
}
